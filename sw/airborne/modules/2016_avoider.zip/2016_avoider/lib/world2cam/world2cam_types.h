/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: world2cam_types.h
 *
 * MATLAB Coder version            : 2.8.1
 * C/C++ source code generated on  : 13-Mar-2016 13:50:05
 */

#ifndef __WORLD2CAM_TYPES_H__
#define __WORLD2CAM_TYPES_H__

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for world2cam_types.h
 *
 * [EOF]
 */
