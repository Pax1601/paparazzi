/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: world2cam_initialize.c
 *
 * MATLAB Coder version            : 2.8.1
 * C/C++ source code generated on  : 13-Mar-2016 13:50:05
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "world2cam.h"
#include "world2cam_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void world2cam_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for world2cam_initialize.c
 *
 * [EOF]
 */
