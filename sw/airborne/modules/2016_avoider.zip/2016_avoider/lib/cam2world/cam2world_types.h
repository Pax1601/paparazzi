/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cam2world_types.h
 *
 * MATLAB Coder version            : 2.8.1
 * C/C++ source code generated on  : 11-Mar-2016 16:57:34
 */

#ifndef __CAM2WORLD_TYPES_H__
#define __CAM2WORLD_TYPES_H__

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for cam2world_types.h
 *
 * [EOF]
 */
