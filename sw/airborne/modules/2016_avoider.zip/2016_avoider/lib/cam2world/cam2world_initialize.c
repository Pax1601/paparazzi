/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cam2world_initialize.c
 *
 * MATLAB Coder version            : 2.8.1
 * C/C++ source code generated on  : 11-Mar-2016 16:57:34
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "cam2world.h"
#include "cam2world_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void cam2world_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for cam2world_initialize.c
 *
 * [EOF]
 */
