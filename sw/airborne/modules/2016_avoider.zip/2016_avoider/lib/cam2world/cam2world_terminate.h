/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: cam2world_terminate.h
 *
 * MATLAB Coder version            : 2.8.1
 * C/C++ source code generated on  : 11-Mar-2016 16:57:34
 */

#ifndef __CAM2WORLD_TERMINATE_H__
#define __CAM2WORLD_TERMINATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "cam2world_types.h"

/* Function Declarations */
extern void cam2world_terminate(void);

#endif

/*
 * File trailer for cam2world_terminate.h
 *
 * [EOF]
 */
